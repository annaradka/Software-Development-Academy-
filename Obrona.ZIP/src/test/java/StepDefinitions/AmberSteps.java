package StepDefinitions;

import io.cucumber.java.AfterAll;
import io.cucumber.java.BeforeAll;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class AmberSteps {

    private static WebDriver driver;
    WebDriverWait wait = new WebDriverWait(driver,Duration.ofMillis(1000));

    @BeforeAll
    public static void setUp() {
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        //driver.manage().timeouts().implicitlyWait(Duration.ofMillis(2000));
    }


    @Given("Uzytkownik przechodzi na strone {string}")
    public void uzytkownik_przechodzi_na_strone(String adresStrony) {
        driver.navigate().to(adresStrony);
    }

    @When("Uzytkownik klika pierwszy raz w przycisk")
    public void uzytkownik_klika_pierwszy_raz_w_przycisk() {
       String pierwszyElement = driver.findElement(By.xpath("/html/body/div/table/tbody/tr[2]/td[2]/code")).getText();
       System.out.println(pierwszyElement);
       if (pierwszyElement.equals("B1")) {
           driver.findElement(By.id("btnButton1")).click();
       } else {
            driver.findElement(By.id("btnButton2")).click();
       }
    }

    @When("Uzytkownik klika drugi raz w przycisk")
    public void uzytkownik_klika_drugi_raz_w_przycisk() {
        String drugiElement = driver.findElement(By.xpath("/html/body/div/table/tbody/tr[3]/td[2]/code")).getText();
        if (drugiElement.equals("B1")) {
            driver.findElement(By.id("btnButton1")).click();
        } else {
            driver.findElement(By.id("btnButton2")).click();
        }
    }

    @When("Uzytkownik klika trzeci raz w przycisk")
    public void uzytkownik_klika_trzeci_raz_w_przycisk() {
       String trzeciElement = driver.findElement(By.xpath("/html/body/div/table/tbody/tr[4]/td[2]/code")).getText();
        if (trzeciElement.equals("B1")) {
            driver.findElement(By.id("btnButton1")).click();
        } else {
            driver.findElement(By.id("btnButton2")).click();
        }
    }

    @When("Uzytkownik klika w przycisk Check Solution")
    public void uzytkownik_klika_w_przycisk_check_solution() throws InterruptedException {
        //Thread.sleep(1000);
        //do uzupelnienia warunek wait.until(ExpectedConditions.textToBePresentInElement(,));
        driver.findElement(By.id("solution")).click();
    }

    @Then("Uzytkownik poprawnie rozwiazal cwiczenie")
    public void uzytkownik_poprawnie_rozwiazal_cwiczenie() throws InterruptedException {
        //Thread.sleep(1000);
        //do uzupelnienia warunek wait.until(ExpectedConditions.textToBePresentInElement(,));
        Assert.assertEquals("OK. Good answer",driver.findElement(By.className("wrap")).getText());
    }

    @AfterAll
    public static void tearDown() {
        driver.quit();
    }

}
